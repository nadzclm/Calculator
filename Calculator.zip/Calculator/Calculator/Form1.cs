﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculator
{
    public partial class Form1 : Form
    {
        bool isOperatorActive = false, isNegative = false;
        int numGrp = 0;
        string operation = "";
        double num1 = 0, ans = 0, num2= 0;
        List<double> memory = new List<double>();
        char[] characters = {'=', '/', '(', ')', '%', '√' };
        char[] operators = { '=', '/', '%', '+', '-', '*'};


        public Form1()
        {
            InitializeComponent();
        }

        private void button_Click(object sender, EventArgs e)
        {
            
            if (labelAns.Text == "0" || isOperatorActive)
            {
                isOperatorActive = false;
                labelAns.Text = ((Button)sender).Text;
            }
            else
            {
                labelAns.Text = labelAns.Text + ((Button)sender).Text;
            }
           
        }

        private void buttonClear_Click(object sender, EventArgs e)
        {

        }

        private void buttonCE_Click(object sender, EventArgs e)
        {

        }

        private void buttonDelete_Click(object sender, EventArgs e)
        {

        }

        private void buttonDot_Click(object sender, EventArgs e)
        {
            if (!labelAns.Text.Contains("."))
            {
                labelAns.Text = labelAns.Text + ".";
            }
        }
       
        private bool checkCharacters(string op)
        {
            foreach (char chars in characters)
            {
                if (op.Contains(chars))
                {
                    return true;
                }
            }
            return false;
        }

        private void buttonOperator_Click(object sender, EventArgs e)
        {
            try
            {
                Button objButton = ((Button)sender);
                isOperatorActive = true;


                if (objButton.Text == "+")
                {
                    if (checkActiveOperation(objButton.Text) && !checkCharacters(labelOperation.Text))
                    {

                        num1 = Convert.ToDouble(labelOperation.Text.Replace(operation, ""));
                        labelAns.Text = calculate(operation, true).ToString();
                        operation = objButton.Text;
                        labelOperation.Text = labelAns.Text + objButton.Text;

                    }
                    else
                    {
                        num1 = Convert.ToDouble(labelAns.Text);
                        operation = "+";
                        labelOperation.Text = labelAns.Text + objButton.Text;
                    }

                }
                else if (objButton.Text == "-")
                {
                    if (checkActiveOperation(objButton.Text) && !checkCharacters(labelOperation.Text))
                    {
                        num1 = Convert.ToDouble(labelOperation.Text.Replace(operation, ""));
                        labelAns.Text = calculate(operation, true).ToString();
                        operation = objButton.Text;
                        labelOperation.Text = labelAns.Text + operation;

                    }
                    else
                    {
                        num1 = Convert.ToInt32(labelAns.Text);
                        operation = "-";
                        labelOperation.Text = labelAns.Text + objButton.Text;
                    }
                }
                else if (objButton.Text == "✕")
                {
                    if (checkActiveOperation(objButton.Text) && !checkCharacters(labelOperation.Text))
                    {
                        num1 = Convert.ToDouble(labelOperation.Text.Replace(operation, ""));
                        labelAns.Text = calculate(operation, true).ToString();
                        operation = objButton.Text;
                        labelOperation.Text = labelAns.Text + operation;

                    }
                    else
                    {
                        num1 = Convert.ToInt32(labelAns.Text);
                        operation = "✕";
                        labelOperation.Text = labelAns.Text + objButton.Text;
                    }
                }
                else if (objButton.Text == "÷")
                {
                    if (checkActiveOperation(objButton.Text) && !checkCharacters(labelOperation.Text))
                    {
                        num1 = Convert.ToDouble(labelOperation.Text.Replace(operation, ""));
                        labelAns.Text = calculate(operation, true).ToString();
                        operation = objButton.Text;
                        labelOperation.Text = labelAns.Text + operation;

                    }
                    else
                    {
                        num1 = Convert.ToInt32(labelAns.Text);
                        operation = "÷";
                        labelOperation.Text = labelAns.Text + objButton.Text;
                    }
                }
                else if (objButton.Text == "%")
                {
                    if (checkActiveOperation(objButton.Text) && !checkCharacters(labelOperation.Text))
                    {

                        num1 = Convert.ToInt32(labelAns.Text);
                        labelAns.Text = calculate("%", false).ToString();
                        num2 = num1;
                        num1 = Convert.ToDouble(labelOperation.Text.Replace(operation, ""));
                        labelAns.Text = calculate(operation, true).ToString();
                        labelOperation.Text = num1 + operation + num2 + objButton.Text;
                        operation = objButton.Text;


                    }
                    else
                    {
                        num1 = Convert.ToInt32(labelAns.Text);
                        operation = "%";
                        labelOperation.Text = labelAns.Text + objButton.Text;
                        labelAns.Text = calculate(operation, true).ToString();
                    }
                }

                else if (objButton.Text == "1/x")
                {
                    if (checkActiveOperation(objButton.Text) && !checkCharacters(labelOperation.Text))
                    {

                        num1 = Convert.ToInt32(labelAns.Text);
                        labelAns.Text = calculate("1/x", false).ToString();
                        num2 = num1;
                        num1 = Convert.ToDouble(labelOperation.Text.Replace(operation, ""));
                        labelAns.Text = calculate(operation, true).ToString();
                        labelOperation.Text = num1 + operation + "1/( " + num2 + ")";
                        operation = objButton.Text;


                    }
                    else
                    {
                        num1 = Convert.ToInt32(labelAns.Text);
                        labelOperation.Text = "1/(" + labelAns.Text + ")";
                        labelAns.Text = calculate(objButton.Text, true).ToString();
                    }
                }
                else if (objButton.Text == "√")
                {
                    if (checkActiveOperation(objButton.Text) && !checkCharacters(labelOperation.Text))
                    {

                        num1 = Convert.ToInt32(labelAns.Text);
                        labelAns.Text = calculate("√", false).ToString();
                        num2 = num1;
                        num1 = Convert.ToDouble(labelOperation.Text.Replace(operation, ""));
                        labelAns.Text = calculate(operation, true).ToString();
                        labelOperation.Text = num1 + operation + num2 + objButton.Text;
                        operation = objButton.Text;


                    }
                    else
                    {
                        num1 = Convert.ToInt32(labelAns.Text);
                        labelOperation.Text = "√(" + labelAns.Text + ")";
                        labelAns.Text = calculate(objButton.Text, true).ToString();
                    }
                }
                else if (objButton.Text == "=")
                {
                    num1 = Convert.ToDouble(labelOperation.Text.Replace(operation, ""));
                    labelOperation.Text = labelOperation.Text + labelAns.Text + objButton.Text;
                    labelAns.Text = calculate(operation, true).ToString();

                }
                else if (objButton.Text == "+/-")
                {
                    if (!isNegative)
                    {
                        labelAns.Text = "-" + labelAns.Text;
                        isNegative = true;
                    }
                    else
                    {
                        labelAns.Text = labelAns.Text.Replace("-", "");
                        isNegative = false;
                    }
                }
                else if (objButton.Text == "C")
                {
                    labelAns.Text = "0";
                    labelOperation.Text = "";
                }
                else if (objButton.Text == "CE")
                {
                    labelAns.Text = "0";

                    if (labelOperation.Text.Contains("="))
                    {
                        labelOperation.Text = "";
                    }
                }
                else if (objButton.Text == "DEL")
                {
                    labelAns.Text = labelAns.Text.Remove(labelAns.Text.Length - 1);

                    if (labelAns.Text.Length == 0)
                    {
                        labelAns.Text = "0";
                    }
                }

            }
            catch
            {
                MessageBox.Show("Invalid Operation");
            }
        }

        private void buttonMemoryStore_Click(object sender, EventArgs e)
        {
            memory.Add(Convert.ToDouble(labelAns.Text));

                numGrp = tabPage2.Controls.Count;

            if(numGrp == 0)
            {
                tabPage2.Controls.Add(CreateMemoryGroupBox(155, 80, numGrp * 80, memory.Last()));
            }
             else
            {
                int y = numGrp;
                for (int i = 0; i < numGrp; i++)
                {    
                    tabPage2.Controls[i].Location = new Point(0, y * 80);
                    y--;         
                }
                tabPage2.Controls.Add(CreateMemoryGroupBox(155, 80, 0, memory.Last()));
            }
            if(numGrp != 0)
            {
                buttonMemoryClear.Enabled = true;
                buttonMemoryRecall.Enabled = true;
            }
        }

        private bool checkActiveOperation(string operation)
        {
            if (labelOperation.Text.Contains("+") || labelOperation.Text.Contains("-") || labelOperation.Text.Contains("✕") || labelOperation.Text.Contains("÷"))
            {

                return true;
            }
            else
            {
                return false;
            }
        }

        private double calculate (string operation, bool recordHistory)
        {
            if (operation == "+")
            {
                ans = num1 + Convert.ToDouble(labelAns.Text);
            }
            else if (operation == "-")
            {
                ans = num1 - Convert.ToDouble(labelAns.Text);
            }
            else if (operation == "✕")
            {
                ans = num1 * Convert.ToDouble(labelAns.Text);
            }
            else if (operation == "÷")
            {
                ans = num1 / Convert.ToDouble(labelAns.Text);
            }
            else if (operation == "%")
            {
                ans = num1 / 100;
            }
            else if (operation == "1/x")
            {
                ans = 1 / num1;
            }
            else if (operation == "√")
            {
                ans = Math.Sqrt(num1);
            }

            if (recordHistory)
            {
                numGrp = tabPage1.Controls.Count;
                string op = num1.ToString() + operation + Convert.ToDouble(labelAns.Text) + "=";

                if (numGrp == 0)
                {
                    tabPage1.Controls.Add(CreateHistGroupBox(155, 80, numGrp * 80, ans, op));
                }
                else
                {
                    int y = numGrp;
                    for (int i = 0; i < numGrp; i++)
                    {
                        tabPage1.Controls[i].Location = new Point(0, y * 80);
                        y--;
                    }
                    tabPage1.Controls.Add(CreateHistGroupBox(155, 80, 0, ans, op));
                }
            }

            return ans;
        }

        private void buttonMemoryMinus_Click(object sender, EventArgs e)
        {
            numGrp = tabPage2.Controls.Count;

            if (numGrp == 0)
            {
                memory.Add(Convert.ToDouble(labelAns.Text));
                tabPage2.Controls.Add(CreateMemoryGroupBox(155, 80, numGrp * 80, memory.Last()));
            }
            else
            {
                tabPage2.Controls[numGrp - 1].Controls[0].Text = (memory.Last() - Convert.ToDouble(labelAns.Text)).ToString();
                memory.Add((memory.Last() - Convert.ToDouble(labelAns.Text)));
            }
            buttonMemoryClear.Enabled = true;
            buttonMemoryRecall.Enabled = true;
        }

        private void buttonMemoryAdd_Click(object sender, EventArgs e)
        {
            numGrp = tabPage2.Controls.Count;

            if (numGrp == 0)
            {
                memory.Add(Convert.ToDouble(labelAns.Text));
                tabPage2.Controls.Add(CreateMemoryGroupBox(155, 80, numGrp * 80, memory.Last()));
               
            }
            else
            {
                tabPage2.Controls[numGrp - 1].Controls[0].Text = (memory.Last() + Convert.ToDouble(labelAns.Text)).ToString();
                memory.Add((memory.Last() + Convert.ToDouble(labelAns.Text)));
            }


                buttonMemoryClear.Enabled = true;
                buttonMemoryRecall.Enabled = true;
        }

        private void buttonMemoryRecall_Click(object sender, EventArgs e)
        {
            labelAns.Text = memory.Last().ToString();
        }

        private void buttonMemoryClear_Click(object sender, EventArgs e)
        {
            numGrp = tabPage2.Controls.Count;
            memory.Clear();

            for (int i = numGrp-1; i >= 0; i--)
            {
                tabPage2.Controls.RemoveAt(i);
            }

            buttonMemoryRecall.Enabled = false;
            buttonMemoryClear.Enabled = false;

        }

        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {

        }

        private void exportToTextToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFileDialog1 = new SaveFileDialog();

            saveFileDialog1.FileName = "CalculatorHistory.txt";

            saveFileDialog1.Filter = "Text File | *.txt";   
            numGrp = tabPage1.Controls.Count;


            // Create a new file     
            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                using (StreamWriter sw = File.CreateText(saveFileDialog1.FileName))
                {
                    for (int i = 0; i < numGrp; i++)
                    {
                        sw.WriteLine("{0} {1} ", tabPage1.Controls[i].Controls[0].Text, tabPage1.Controls[i].Controls[1].Text);
                    }

                }
            }
        }

        private void importToTextToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //string[] lines = System.IO.File.ReadAllLines(@"C:\Users\bernadine.f.a.coloma\Documents\Visual Studio 2015\Projects\Calculator\Calculator\CalculatorHistoy.txt");

            OpenFileDialog openFileDialog1 = new OpenFileDialog
            {
                InitialDirectory = @"C:\",
                Title = "Browse Text Files",

                CheckFileExists = true,
                CheckPathExists = true,

                DefaultExt = "txt",
                Filter = "txt files (*.txt)|*.txt",
                FilterIndex = 2,
                RestoreDirectory = true,

                ReadOnlyChecked = true,
                ShowReadOnly = true
            };

            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                string[] lines = System.IO.File.ReadAllLines(openFileDialog1.FileName);

                numGrp = tabPage1.Controls.Count;
                for (int i = numGrp - 1; i >= 0; i--)
                {
                    tabPage1.Controls.RemoveAt(i);
                }

                foreach (string line in lines)
                {
                    numGrp = tabPage1.Controls.Count;
                    string[] ans = line.Split('=');
                    tabPage1.Controls.Add(CreateHistGroupBox(155, 80, numGrp * 80, Convert.ToDouble(ans[1]), ans[0] + "="));
                }
            }

          
        }

        private void clearToolStripMenuItem_Click(object sender, EventArgs e)
        {
            labelAns.Text = "0";
            labelOperation.Text = "";

            numGrp = tabPage1.Controls.Count;
            for (int i = numGrp - 1; i >= 0; i--)
            {
                tabPage1.Controls.RemoveAt(i);
            }

            numGrp = tabPage2.Controls.Count;

            for (int i = numGrp - 1; i >= 0; i--)
            {
                tabPage2.Controls.RemoveAt(i);
            }

            buttonMemoryClear.Enabled = false;
            buttonMemoryStore.Enabled = false;

        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void copyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Clipboard.SetText(labelAns.Text);

            MessageBox.Show("Successfully copied to clipboard!");
        }

        private void Form1_KeyPress(object sender, KeyPressEventArgs e)
        {
            //MessageBox.Show(e.KeyChar.ToString());
            if ((Char.IsDigit(e.KeyChar) || (e.KeyChar == (char)Keys.Back)))
            {
                Button button = new Button();
                button.Text = e.KeyChar.ToString();
                button_Click(button, e);
            }
            else if (e.KeyChar == (char)Keys.Enter)
            {
                Button button = new Button();
                button.Text = "=";

                buttonOperator_Click(button, e);

            }
            else 
            {
                foreach (char op in operators)
                {
                    if (e.KeyChar == op)
                    {
                        Button button = new Button();
                        if (e.KeyChar == '*')
                        {
                            button.Text = "✕";
                        }
                        else if (e.KeyChar == '/')
                        {
                            button.Text = "÷";
                        }
                        else
                        {
                            button.Text = e.KeyChar.ToString();
                        }
                        

                        buttonOperator_Click(button, e);

                    }
                }
              
            }
        }

        private void pasteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            labelAns.Text = Clipboard.GetText();
        }

        private GroupBox CreateHistGroupBox (int width, int height, int y, double ans, string op)
        {
            GroupBox g = new GroupBox();
            g.Size = new Size(width, height);
            g.Location = new Point(0, y);

            Label historyOperation = new Label();
            historyOperation.Text = op;
            historyOperation.Location = new Point(0, 10);
            historyOperation.AutoSize = false;

            Label historyAnswer = new Label();
            historyAnswer.Text = ans.ToString();
            historyAnswer.Location = new Point(0, 35);
            historyAnswer.AutoSize = false;
            historyAnswer.Font = new Font("Arial", 10, FontStyle.Bold);


            g.Controls.Add(historyOperation);
            g.Controls.Add(historyAnswer);

            return g;
        }


        private GroupBox CreateMemoryGroupBox(int width, int height, int y, double ans)
        {
            GroupBox g = new GroupBox();
            g.Size = new Size(width, height);
            g.Location = new Point(0, y);
            g.Name = "MemoryGroupBox";

            Label memory = new Label();
            memory.Text = ans.ToString();
            memory.Location = new Point(80, 35);
            memory.AutoSize = false;
            memory.Font = new Font("Arial", 10, FontStyle.Bold);


           
            g.Controls.Add(memory);

            return g;
        }
    }
}
